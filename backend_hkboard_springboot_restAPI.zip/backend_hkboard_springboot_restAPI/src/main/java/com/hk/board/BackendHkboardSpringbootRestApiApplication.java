package com.hk.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendHkboardSpringbootRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendHkboardSpringbootRestApiApplication.class, args);
	}

}
