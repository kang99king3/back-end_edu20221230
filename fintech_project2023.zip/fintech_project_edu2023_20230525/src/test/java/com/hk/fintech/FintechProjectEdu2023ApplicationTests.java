package com.hk.fintech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FintechProjectEdu2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
