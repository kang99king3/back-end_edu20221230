package com.hk.fintech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class FintechProjectEdu2023Application {

	public static void main(String[] args) {
		SpringApplication.run(FintechProjectEdu2023Application.class, args);
	}

}
