package com.hk.fintech.apidto;

import lombok.Data;

@Data
public class UserMePayDto {
	private String bank_code_std;
	private String inquiry_agree_dtime;
}
